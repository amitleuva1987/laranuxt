<template>
  <div class="container m-20 flex flex-col items-center justify-center bg-white">
    <div class="flex flex-wrap max-w-xl my-20">
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconBang/&gt;</span>
        <IconBang class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconCheck/&gt;</span>
        <IconCheck class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconInfo/&gt;</span>
        <IconInfo class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconTimes/&gt;</span>
        <IconTimes class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconEnvelope/&gt;</span>
        <IconEnvelope class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconPhone/&gt;</span>
        <IconPhone class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconSignIn/&gt;</span>
        <IconSignIn class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconToast/&gt;</span>
        <IconToast class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconGithub/&gt;</span>
        <IconGithub class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconNuxt/&gt;</span>
        <IconNuxt class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconLaravel/&gt;</span>
        <IconLaravel class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconBell/&gt;</span>
        <IconBell class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconCalendar/&gt;</span>
        <IconCalendar class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconMarker/&gt;</span>
        <IconMarker class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconOfficePhone/&gt;</span>
        <IconOfficePhone class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconSearch/&gt;</span>
        <IconSearch class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2 mt-2">
        <span class="mr-2 text-gray-500 text-sm">&lt;IconSpinner/&gt;</span>
        <IconSpinner class="w-5 h-5" />
      </div>
    </div>
    <div class="flex my-20">
      <div class="bg-white p-2 rounded border mr-10">
        <IconCheck primary="text-green-300" secondary="text-green-400" class="w-5 h-5" />
      </div>
      <div class="bg-white p-2 rounded border flex mr-2">
        <IconBang class="w-5 h-5" primary="text-red-300" secondary="text-red-400" />
      </div>
    </div>
  </div>
</template>
