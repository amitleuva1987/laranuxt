<template>
  <div>
  <!-- <nav class="p-5 flex flex-row bg-red-400">
        <div class="md:w-1/2">Brand</div>
        <div class="md:w-1/2 flex justify-end space-x-5">
            <a href="#">Sign up</a>
            <a href="#">Login</a>
        </div>
  </nav> -->
  <div class="flex items-center justify-center">
    <Nuxt />
  </div>
  </div> 
</template>

<style>
html,body {
  @apply bg-gray-100
}
</style>
