<template>
    <form class="w-full border-b-2 border-yellow-900 pb-3 mb-3">
    <h2 class="text-xl mb-3 border-b-2 border-yellow-900 pb-3">Personal Details</h2>    
    <div class="flex flex-wrap -mx-3 mb-6">
    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-first-name">
        Name
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-red-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="grid-first-name" type="text" placeholder="Jane" v-model="user.name">
      <p class="text-red-500 text-xs italic">Please fill out this field.</p>
    </div>
    <div class="w-full md:w-1/2 px-3">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-job-title">
        Job Title
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-job-title" type="text" placeholder="Full stack developer" v-model="user.job_title">
    </div>
  </div>

  <div class="flex flex-wrap -mx-3 mb-6">
    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-github">
        Github Profile
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-red-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="grid-github" type="text" placeholder="Jane" v-model="user.github_profile">
      <p class="text-red-500 text-xs italic">Please fill out this field.</p>
    </div>
    <div class="w-full md:w-1/2 px-3">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-linkedin">
        Linkedin Profile
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-linkedin" type="text" placeholder="https://linkedin.com/profile" v-model="user.linkedin_profile">
    </div>
  </div>
  
  <div class="flex flex-wrap -mx-3 mb-6">
    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-mobile-no">
        Mobile Number
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-mobile-no" type="text" placeholder="+1 123 234" v-model="user.mobile_no">
    </div>
    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-email">
        Email
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-email" type="text" placeholder="myname@example.com" v-model="user.email">
    </div>
    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-location">
        Location
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-location" type="text" placeholder="city, country" v-model="user.location">
    </div>
  </div>

  <div class="flex flex-wrap -mx-3 mb-6">
    <div class="w-full px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-mobile-no">
        Description
      </label>
      <textarea class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-responsibility-no" placeholder="Description" v-model="user.description"></textarea>
    </div>
  </div>  
   
  <div class="w-full flex justify-center">
    <button class="bg-blue-500 hover:bg-blue-700 border-blue-500 hover:border-blue-700 text-md border-4 text-white py-2 px-3 rounded" type="button" @click.once="update_user">
     SAVE
    </button>
  </div>
</form>    
</template>

<script lang="ts">
import Vue from 'vue'
import { User } from '@/types/api'
export default Vue.extend({
    name: 'UserDetails',
    data () {
    const user = {} as User 
    return{
        user
    }
  },
  mounted () {
    this.get_user();
  },
  methods: {
    async get_user():Promise<void> {
        this.user = ( 
            await this.$axios.get('users/1')
        ).data.data as User;
    },

    async update_user():Promise<void> {
      let data = {
        'name': this.user.name,
        'email': this.user.email,
        'job_title': this.user.job_title,
        'mobile_no': this.user.mobile_no,
        'github_profile': this.user.github_profile,
        'linkedin_profile': this.user.linkedin_profile,
        'location': this.user.location,
        'description':this.user.description
      }
      this.$axios.put('users/1',data).then(response => {
          this.$toast.show({
          type: 'success',
          title: 'Success',
          message: 'Profile Updated Successfully',
          })
          this.get_user()
      }).catch(error => {
          this.$toast.show({
          type: 'danger',
          title: 'Error',
          message: 'Oops, something went wrong',
      })
      });
    }
  },
})    
</script>
