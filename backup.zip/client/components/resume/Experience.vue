<template>
<section>
     <h2 class="text-xl mb-3 border-b-2 border-yellow-900 pb-3">Experience</h2>
     <ul>
        <li v-for="experience in experiences" :key="experience.id" class="bg-white px-3 py-2 flex justify-between mb-2">
            <span>{{ experience.company_name }} | {{ experience.job_title }} ({{ experience.from_date }} - {{ experience.to_date }})</span>
            <span><button type="button" @click.once="edit(experience)" class="text-blue-500">Edit</button> | <button type="button" @click.once="danger(experience.id)" class="text-red-500">Delete</button></span>
        </li>
     </ul>
     <add-experience @refresh_experience="get_experiences()" />
     <edit-experience @refresh_experience="refresh_edit()" v-if="enable_edit" :experience="experience" />    
</section>    
</template>

<script lang="ts">
import Vue from 'vue'
import { Experience } from '@/types/api'
import AddExperience from './AddExperience.vue'
import EditExperience from './EditExperience.vue'
export default Vue.extend({
  components: { AddExperience, EditExperience },
    name:'Experience',
    data(){
        const experiences:Experience[] = []
        const enable_edit:boolean = false
        const experience = {} as Experience
        return{
            experiences,
            enable_edit,
            experience
        }
    },
    mounted(){
        this.get_experiences()
    },
    methods:{
        async refresh_edit():Promise<void>{
            this.experiences = (await this.$axios.get('experiences')).data.data as Experience[]   
            this.enable_edit = !this.enable_edit
        },
        edit(experience:Experience):void{
            this.experience = experience
            this.enable_edit = !this.enable_edit
        },
        async get_experiences(): Promise<void>{
            this.experiences = (await this.$axios.get('experiences')).data.data as Experience[]   
        },
        danger (id:number) {
        this.$modal.show({
            type: 'danger',
            title: 'Are you sure?',
            body: 'once removed, you will not be able to get it back.',
            secondary: {
            label: 'Cancel',
            theme: 'while',
            action: () => this.$toast.success('You cancelled deletion'),
            },
            primary: {
            label: 'Confirm Delete',
            theme: 'red',
            action: () => this.delete_experience(id),
            },
        })
        },

        async delete_experience(id:number){
            let url = 'experiences/'+id
            await this.$axios.delete(url).then(response => {
                this.get_experiences()
                this.$toast.show({
                type: 'success',
                title: 'Success',
                message: 'Skill Deleted Successfully',
                })
            }).catch(error => {
                this.$toast.show({
                type: 'danger',
                title: 'Error',
                message: 'Oops, something went wrong',
            })
            });

        }

    }
})
</script>