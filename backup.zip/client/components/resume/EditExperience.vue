<template>
<section>
    <form class="w-full border-b-2 border-yellow-900 pb-3 mb-3 mt-5">
    <div class="flex flex-wrap -mx-3 mb-6">
    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-company-name">
        Company Name
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-red-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="grid-company-name" type="text" placeholder="ABC Pvt ltd" v-model="experience.company_name">
      <p class="text-red-500 text-xs italic">Please fill out this field.</p>
    </div>
    <div class="w-full md:w-1/2 px-3">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-job-title">
        Job Title
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-job-title" type="text" placeholder="Full stack developer" v-model="experience.job_title">
    </div>
  </div>

  <div class="flex flex-wrap -mx-3 mb-6">
    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-github">
        From Date
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-red-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="grid-from-date" type="date" v-model="experience.from_date" >
      <p class="text-red-500 text-xs italic">Please fill out this field.</p>
    </div>
    <div class="w-full md:w-1/2 px-3">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-linkedin">
        To Date
      </label>
      <input class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-to-date" type="date" v-model="experience.to_date">
    </div>
  </div>
  
  <div class="flex flex-wrap -mx-3 mb-6">
    <div class="w-full px-3 mb-6 md:mb-0">
      <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-mobile-no">
        Responsiblities
      </label>
      <textarea class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500" id="grid-responsibility-no" placeholder="Responsibilities" v-model="experience.responsibilities"></textarea>
    </div>
  </div>
   
   
  <div class="w-full flex justify-center">
    <button class="bg-blue-500 hover:bg-blue-700 border-blue-500 hover:border-blue-700 text-md border-4 text-white py-2 px-3 rounded" type="button" @click.once="save_experience">
     SAVE
    </button>
    <button class="ml-2 bg-white text-md py-2 px-3 rounded" type="button" @click.once="show_add_experiemce_form = !show_add_experiemce_form">
     CANCEL
    </button>
  </div>
</form>  
</section>      
</template>

<script lang="ts">
import Vue from 'vue'
import { Experience } from '@/types/api' 
export default Vue.extend({
    name:'EditExperience',
    props:{
      experience: {
        required: true,
        type: Object as () => Experience,
      },
    },
    
    methods:{
      async save_experience():Promise<void>{
            let data = {
                'company_name':this.experience.company_name,
                'job_title':this.experience.job_title,
                'from_date':this.experience.from_date,
                'to_date':this.experience.to_date,
                'responsibilities':this.experience.responsibilities
            }
            
            let url = 'experiences/'+this.experience.id
            await this.$axios.put(url,data).then(response => {
                this.$toast.show({
                type: 'success',
                title: 'Success',
                message: 'Experience Update Successfully',
                })
                this.$emit('refresh_experience')
            }).catch(error => {
                this.$toast.show({
                type: 'danger',
                title: 'Error',
                message: 'Oops, something went wrong',
                })
            })
        }
    }
})
</script>