<template>
<section>
     <h2 class="text-xl mb-3 border-b-2 border-yellow-900 pb-3">Education</h2>
     <ul>
        <li v-for="education in educations" :key="education.id" class="bg-white px-3 py-2 flex justify-between mb-2">
            <span>{{ education.degree_name }} | {{ education.university_name }} ({{ education.from_date }} - {{ education.to_date }})</span>
            <span><button type="button" @click.once="edit(education)" class="text-blue-500">Edit</button> | <button type="button" @click.once="danger(education.id)" class="text-red-500">Delete</button></span>
        </li>
     </ul>
     <add-education @refresh_education="get_educations()" />
     <edit-education @refresh_education="refresh_edit()" v-if="enable_edit" :education="education" />    
</section>
</template>
<script lang="ts">
import Vue from 'vue'
import { Education } from '@/types/api'
import AddEducation from './AddEducation.vue'
import EditEducation from './EditEducation.vue'
export default Vue.extend({
  components: { AddEducation, EditEducation },
    name:'Education',
    data(){
        const educations:Education[] = []
        const enable_edit:boolean = false
        const education = {} as Education
        return{
            educations,
            enable_edit,
            education
        }
    },
    mounted(){
        this.get_educations()
    },
    methods:{
        async refresh_edit():Promise<void>{
            this.educations = (await this.$axios.get('educations')).data.data as Education[]   
            this.enable_edit = !this.enable_edit
        },
        edit(education:Education):void{
            this.education = education
            this.enable_edit = !this.enable_edit
        },
        async get_educations(): Promise<void>{
            this.educations = (await this.$axios.get('educations')).data.data as Education[]   
        },

        danger (id:number) {
        this.$modal.show({
            type: 'danger',
            title: 'Are you sure?',
            body: 'once removed, you will not be able to get it back.',
            secondary: {
            label: 'Cancel',
            theme: 'while',
            action: () => this.$toast.success('You cancelled deletion'),
            },
            primary: {
            label: 'Confirm Delete',
            theme: 'red',
            action: () => this.delete_education(id),
            },
        })
        },

        async delete_education(id:number){
            let url = 'educations/'+id
            await this.$axios.delete(url).then(response => {
                this.get_educations()
                this.$toast.show({
                type: 'success',
                title: 'Success',
                message: 'Education Deleted Successfully',
                })
            }).catch(error => {
                this.$toast.show({
                type: 'danger',
                title: 'Error',
                message: 'Oops, something went wrong',
            })
            });

        }
    }
})
</script>