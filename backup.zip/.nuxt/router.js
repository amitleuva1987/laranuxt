import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _02ab3b70 = () => interopDefault(import('..\\client\\pages\\button.vue' /* webpackChunkName: "pages/button" */))
const _ad627292 = () => interopDefault(import('..\\client\\pages\\icon.vue' /* webpackChunkName: "pages/icon" */))
const _575f575f = () => interopDefault(import('..\\client\\pages\\modal.vue' /* webpackChunkName: "pages/modal" */))
const _1cad4e47 = () => interopDefault(import('..\\client\\pages\\profile\\index.vue' /* webpackChunkName: "pages/profile/index" */))
const _3498b44e = () => interopDefault(import('..\\client\\pages\\toast.vue' /* webpackChunkName: "pages/toast" */))
const _28187025 = () => interopDefault(import('..\\client\\pages\\profile\\edit.vue' /* webpackChunkName: "pages/profile/edit" */))
const _b42e29f8 = () => interopDefault(import('..\\client\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/button",
    component: _02ab3b70,
    name: "button"
  }, {
    path: "/icon",
    component: _ad627292,
    name: "icon"
  }, {
    path: "/modal",
    component: _575f575f,
    name: "modal"
  }, {
    path: "/profile",
    component: _1cad4e47,
    name: "profile"
  }, {
    path: "/toast",
    component: _3498b44e,
    name: "toast"
  }, {
    path: "/profile/edit",
    component: _28187025,
    name: "profile-edit"
  }, {
    path: "/",
    component: _b42e29f8,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
