export const isFullStatic = false
export const staticPath = "C:/xampp1/htdocs/solution_8/.nuxt/static-json"
export const publicPath = "/"
export const globalContext = "__NUXT__"
export const globalNuxt = "$nuxt"