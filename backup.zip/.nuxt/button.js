import Vue from 'vue'
import TvButton from 'tv-button'
Vue.use(TvButton)
