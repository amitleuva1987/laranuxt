# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<ContactCard>` | `<contact-card>` (components/cards/ContactCard.vue)
- `<ContactCardSkeleton>` | `<contact-card-skeleton>` (components/cards/ContactCardSkeleton.vue)
- `<Logo>` | `<logo>` (components/Logo.vue)
- `<ResumeAddEducation>` | `<resume-add-education>` (components/resume/AddEducation.vue)
- `<ResumeAddExperience>` | `<resume-add-experience>` (components/resume/AddExperience.vue)
- `<ResumeAddHobby>` | `<resume-add-hobby>` (components/resume/AddHobby.vue)
- `<ResumeAddLanguage>` | `<resume-add-language>` (components/resume/AddLanguage.vue)
- `<ResumeAddSkill>` | `<resume-add-skill>` (components/resume/AddSkill.vue)
- `<ResumeEditEducation>` | `<resume-edit-education>` (components/resume/EditEducation.vue)
- `<ResumeEditExperience>` | `<resume-edit-experience>` (components/resume/EditExperience.vue)
- `<ResumeEditHobby>` | `<resume-edit-hobby>` (components/resume/EditHobby.vue)
- `<ResumeEditLanguage>` | `<resume-edit-language>` (components/resume/EditLanguage.vue)
- `<ResumeEditSkill>` | `<resume-edit-skill>` (components/resume/EditSkill.vue)
- `<ResumeEducation>` | `<resume-education>` (components/resume/Education.vue)
- `<ResumeExperience>` | `<resume-experience>` (components/resume/Experience.vue)
- `<ResumeHobby>` | `<resume-hobby>` (components/resume/Hobby.vue)
- `<ResumeLanguage>` | `<resume-language>` (components/resume/Language.vue)
- `<ResumeListSkills>` | `<resume-list-skills>` (components/resume/ListSkills.vue)
- `<ResumeUserDetails>` | `<resume-user-details>` (components/resume/UserDetails.vue)
