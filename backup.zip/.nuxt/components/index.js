export { default as ContactCard } from '../..\\client\\components\\cards\\ContactCard.vue'
export { default as ContactCardSkeleton } from '../..\\client\\components\\cards\\ContactCardSkeleton.vue'
export { default as Logo } from '../..\\client\\components\\Logo.vue'
export { default as ResumeAddEducation } from '../..\\client\\components\\resume\\AddEducation.vue'
export { default as ResumeAddExperience } from '../..\\client\\components\\resume\\AddExperience.vue'
export { default as ResumeAddHobby } from '../..\\client\\components\\resume\\AddHobby.vue'
export { default as ResumeAddLanguage } from '../..\\client\\components\\resume\\AddLanguage.vue'
export { default as ResumeAddSkill } from '../..\\client\\components\\resume\\AddSkill.vue'
export { default as ResumeEditEducation } from '../..\\client\\components\\resume\\EditEducation.vue'
export { default as ResumeEditExperience } from '../..\\client\\components\\resume\\EditExperience.vue'
export { default as ResumeEditHobby } from '../..\\client\\components\\resume\\EditHobby.vue'
export { default as ResumeEditLanguage } from '../..\\client\\components\\resume\\EditLanguage.vue'
export { default as ResumeEditSkill } from '../..\\client\\components\\resume\\EditSkill.vue'
export { default as ResumeEducation } from '../..\\client\\components\\resume\\Education.vue'
export { default as ResumeExperience } from '../..\\client\\components\\resume\\Experience.vue'
export { default as ResumeHobby } from '../..\\client\\components\\resume\\Hobby.vue'
export { default as ResumeLanguage } from '../..\\client\\components\\resume\\Language.vue'
export { default as ResumeListSkills } from '../..\\client\\components\\resume\\ListSkills.vue'
export { default as ResumeUserDetails } from '../..\\client\\components\\resume\\UserDetails.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
