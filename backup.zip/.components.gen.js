import Vue from 'vue'
import ContactCard from 'C:/xampp1/htdocs/solution_8/client/components/cards/ContactCard.vue'
import ContactCardSkeleton from 'C:/xampp1/htdocs/solution_8/client/components/cards/ContactCardSkeleton.vue'
import Logo from 'C:/xampp1/htdocs/solution_8/client/components/Logo.vue'
import ResumeAddEducation from 'C:/xampp1/htdocs/solution_8/client/components/resume/AddEducation.vue'
import ResumeAddExperience from 'C:/xampp1/htdocs/solution_8/client/components/resume/AddExperience.vue'
import ResumeAddHobby from 'C:/xampp1/htdocs/solution_8/client/components/resume/AddHobby.vue'
import ResumeAddLanguage from 'C:/xampp1/htdocs/solution_8/client/components/resume/AddLanguage.vue'
import ResumeAddSkill from 'C:/xampp1/htdocs/solution_8/client/components/resume/AddSkill.vue'
import ResumeEditEducation from 'C:/xampp1/htdocs/solution_8/client/components/resume/EditEducation.vue'
import ResumeEditExperience from 'C:/xampp1/htdocs/solution_8/client/components/resume/EditExperience.vue'
import ResumeEditHobby from 'C:/xampp1/htdocs/solution_8/client/components/resume/EditHobby.vue'
import ResumeEditLanguage from 'C:/xampp1/htdocs/solution_8/client/components/resume/EditLanguage.vue'
import ResumeEditSkill from 'C:/xampp1/htdocs/solution_8/client/components/resume/EditSkill.vue'
import ResumeEducation from 'C:/xampp1/htdocs/solution_8/client/components/resume/Education.vue'
import ResumeExperience from 'C:/xampp1/htdocs/solution_8/client/components/resume/Experience.vue'
import ResumeHobby from 'C:/xampp1/htdocs/solution_8/client/components/resume/Hobby.vue'
import ResumeLanguage from 'C:/xampp1/htdocs/solution_8/client/components/resume/Language.vue'
import ResumeListSkills from 'C:/xampp1/htdocs/solution_8/client/components/resume/ListSkills.vue'
import ResumeUserDetails from 'C:/xampp1/htdocs/solution_8/client/components/resume/UserDetails.vue'

Vue.component('ContactCard', ContactCard)
Vue.component('LazyContactCard', ContactCard)
Vue.component('ContactCardSkeleton', ContactCardSkeleton)
Vue.component('LazyContactCardSkeleton', ContactCardSkeleton)
Vue.component('Logo', Logo)
Vue.component('LazyLogo', Logo)
Vue.component('ResumeAddEducation', ResumeAddEducation)
Vue.component('LazyResumeAddEducation', ResumeAddEducation)
Vue.component('ResumeAddExperience', ResumeAddExperience)
Vue.component('LazyResumeAddExperience', ResumeAddExperience)
Vue.component('ResumeAddHobby', ResumeAddHobby)
Vue.component('LazyResumeAddHobby', ResumeAddHobby)
Vue.component('ResumeAddLanguage', ResumeAddLanguage)
Vue.component('LazyResumeAddLanguage', ResumeAddLanguage)
Vue.component('ResumeAddSkill', ResumeAddSkill)
Vue.component('LazyResumeAddSkill', ResumeAddSkill)
Vue.component('ResumeEditEducation', ResumeEditEducation)
Vue.component('LazyResumeEditEducation', ResumeEditEducation)
Vue.component('ResumeEditExperience', ResumeEditExperience)
Vue.component('LazyResumeEditExperience', ResumeEditExperience)
Vue.component('ResumeEditHobby', ResumeEditHobby)
Vue.component('LazyResumeEditHobby', ResumeEditHobby)
Vue.component('ResumeEditLanguage', ResumeEditLanguage)
Vue.component('LazyResumeEditLanguage', ResumeEditLanguage)
Vue.component('ResumeEditSkill', ResumeEditSkill)
Vue.component('LazyResumeEditSkill', ResumeEditSkill)
Vue.component('ResumeEducation', ResumeEducation)
Vue.component('LazyResumeEducation', ResumeEducation)
Vue.component('ResumeExperience', ResumeExperience)
Vue.component('LazyResumeExperience', ResumeExperience)
Vue.component('ResumeHobby', ResumeHobby)
Vue.component('LazyResumeHobby', ResumeHobby)
Vue.component('ResumeLanguage', ResumeLanguage)
Vue.component('LazyResumeLanguage', ResumeLanguage)
Vue.component('ResumeListSkills', ResumeListSkills)
Vue.component('LazyResumeListSkills', ResumeListSkills)
Vue.component('ResumeUserDetails', ResumeUserDetails)
Vue.component('LazyResumeUserDetails', ResumeUserDetails)
